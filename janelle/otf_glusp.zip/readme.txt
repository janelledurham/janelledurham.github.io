Free for personal and commercial use

OTF® Glusp is a display font inspired by the Avant-garde (the movement at the beginning of the last century). And by the streets of Kharkiv.

PLEASE TAG US IF YOU USE OUR FONT
@OBYS_AGENCY

CONTACT US:
INFO@OBYS.AGENCY

https://www.behance.net/obys

https://www.instagram.com/obys_agency/

https://dribbble.com/obys

https://twitter.com/obys_agency

https://www.facebook.com/obysagency

https://www.youtube.com/channel/UCq7Vo0Jt4m6-JFOLNO3xjLQ/videos
